<?php
header("location:panel/");
?>
